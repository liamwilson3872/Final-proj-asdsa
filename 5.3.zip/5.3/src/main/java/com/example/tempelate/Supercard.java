package com.example.tempelate;
import java.util.ArrayList;

public class Supercard extends Cards {

    private int energy = 0;
    private int energyNeeded = 1000;
    private boolean ready = false;
    public Supercard(double health, String name, int speed, String element, String color, Location loco, int damage, String team, int range, double cost) {
        super(health, name, speed, element, color, loco, damage, team, range, cost);
        makesuper();
    }
    public void addenergy(int amount) {
        if (ready==false){
            energy += amount;
            if (energy >= energyNeeded) {
                energy = energyNeeded;
                ready = true;
            }
        }
    }


    public boolean isready() {
        return ready;
    }

    public int getenergy() {
        return energy;
    }

    public int getEnergyneeded() {
        return energyNeeded;
    }

    public void summon() {
        if (ready==true) {
            System.out.println("Super unit summoned!");
        }
    }
    public void applyareaeffect(ArrayList<Cards> allCards) {
        int auraRange = 3;
        for (Cards card : allCards) {

            if (!(card.getteam().equals(this.getteam()))) {
                int dist = Math.abs(card.getloco().getRow() - this.getloco().getRow()) + Math.abs(card.getloco().getCol() - this.getloco().getCol());
                if (dist <= auraRange) {

                    if (name.equals("Alexander The Great")) {
                        card.changespeed(card.getspeed() +1);
                    }

                    if (name.equals("Dracula")) {
                        card.addleechval(5.00);
                    }

                    if (name.equals("Gambler")) {
                        int rnum=(int)(Math.random()*2);
                        if (rnum==1){
                            card.heal(20);

                        }else{
                            card.increasedamage(1);
                        }
                    }
                }
            }else{
                int dist = Math.abs(card.getloco().getRow() - this.getloco().getRow()) + Math.abs(card.getloco().getCol() - this.getloco().getCol());
                if (dist <= auraRange) {

                    if (name.equals("The Alien")) {
                        card.damage(30);
                    }

                }
            }
        }
    }
}