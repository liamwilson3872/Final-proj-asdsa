package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class HelloController {

    private Button btnclick;
    private Label lbldisplay;
    private TextField txtinput;
    private GridPane boardGrid;
    private Button slot1;
    private Button slot2;
    private Game game;
    private Button[][] btn;



    public void initialize() {
        int sizex = 40;
        int sizey = 20;
        btn=new Button[sizex][sizey];
        game=new Game(sizex,sizey);

        int buttonSize = 40;

        for (int y = 0; y < sizey; y++) {
            for (int x = 0; x < sizex; x++) {

                Button tile = new Button();

                tile.setPrefWidth(buttonSize);
                tile.setPrefHeight(buttonSize);
                tile.setStyle("-fx-background-color: #444; -fx-border-color: black;");

                boardGrid.add(tile, x, y);
                btn
            }
        }

    }

    public void drawtiles(){
        for (int i=0;i<game.gettiles().length;i++){
            for (int j=0;j<game.gettiles()[0].length;j++){
                boardGrid.get= new Tile(i,j,"green");
            }
        }    }
    public void btnclick(ActionEvent actionEvent) {

        System.out.println("click");
    }
}