package com.example.tempelate;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> allcards;
    private Tile[][] tiles;

    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];

        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"green");
            }
        }
    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=masterdeck;
        }
    }


}
