package com.example.tempelate;

public class Cards {
    protected double health;
    protected String name;
    protected int speed;
    protected String element;
    protected String color;
    protected Location loco;
    public Cards(double health,String name,int speed,String element,String color,Location location){
        this.health=health;
        this.name=name;
        this.speed=speed;
        this.element=element;
        this.color=color;
        loco=location;
    }
    public double gethealth(){
        return health;
    }
    public String getname(){
        return name ;
    }
    public int getspeed(){
        return speed;
    }
    public String getelement(){
        return element;
    }
    public String getcolor(){
        return color ;
    }
    public boolean areyoudead(){
        if (health>0){
            return true;
        }else{
            return false;
        }
    }
    public Location getloco(){
        return loco;
    }
}
