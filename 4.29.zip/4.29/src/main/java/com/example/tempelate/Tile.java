package com.example.tempelate;

import java.util.ArrayList;

public class Tile {
    private int x;
    private int y;
    private String mastercolor;


    public Tile(int x,int y,String mastercolor){
        this.x=x;
        this.y=y;
        this.mastercolor=mastercolor;
    }




    public String getdisplaycolor(ArrayList<Cards> allcards){
        for (int i=0;i<allcards.size();i++){
            if (allcards.get(i).getloco().comparecords(x,y)){

                return allcards.get(i).getcolor();
            }
        }
        return mastercolor;
    }
}
