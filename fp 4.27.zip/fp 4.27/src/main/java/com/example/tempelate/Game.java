package com.example.tempelate;

import javafx.animation.AnimationTimer;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> enemymasterdeck;
    private ArrayList<Cards> enemydeck;
    private ArrayList<Cards> enemyhand;
    private ArrayList<Cards> allcardsinplay;
    private Tile[][] tiles;
    private Cards selectedcard;
    private boolean repeteattacks;
    private ArrayList<String> stufftodisplay;
    private boolean allowsameteamattacks=false;
    private double p1gold;
    private double p2gold;
    private int tick;
    private ArrayList<Cards> allcardspossible=new ArrayList<>();


    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];
        deck=new ArrayList<>();
        masterdeck=new ArrayList<>();
        hand=new ArrayList<>();
        enemydeck=new ArrayList<>();
        enemymasterdeck=new ArrayList<>();
        enemyhand=new ArrayList<>();
        allcardsinplay=new ArrayList<>();
        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"");
            }
        }
        makepossiblecards();
        repeteattacks=false;
        stufftodisplay=new ArrayList<>();
        allowsameteamattacks=false;
        p1gold=9999;
        p2gold=9999;
        tick=0;
        maketestdeck();

    }

    public Cards getselectedcard(){
        return selectedcard;
    }
    public boolean getrepeteattacks(){
        return repeteattacks;
    }
    public void changerepete(boolean news){
        repeteattacks=news;
    }
    public void setselectedcard(Cards card){
        selectedcard=card;
    }
    public ArrayList<Cards> getdeck(){
        return deck;
    }
    private int delay=0;
    public void nexttick() {
        tick+=1;
        for (int i=0;i<allcardsinplay.size();i++) {
            allcardsinplay.get(i).tick(allcardsinplay);

        }
        if (delay==15){
            calcgold();
            delay=0;
            System.out.println(p1gold);
        }else{
            delay+=1;
        }
    }



    public void attackselect(Cards attacker, Cards deffender){
        if (repeteattacks==true){
            autoattack(attacker,deffender);
        }else {
            if (attacker.gettarget() != null) {

                Location target = attacker.gettarget();
                Location deffende = deffender.getloco();
                if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                    if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                        if (allowsameteamattacks==true){
                            battle(attacker, deffender);

                        }else {
                            if (!(attacker.getteam().equals(deffender.getteam()))) {
                                battle(attacker, deffender);
                            } else {
                                System.out.println("ERROR CANT ATTACK YOUR OWN TEAM");
                                stufftodisplay.add("cant attack your own team error");
                            }
                        }
                    }
                }
            }
        }



    }
    public double getplayergold(){
        return p1gold;
    }
    public double getenemygold(){
        return p2gold;
    }
    public void calcgold(){
        double tick=Double.valueOf(this.tick);
        double multiplyer=tick/10;
        p1gold+=(1+multiplyer);
        p2gold+=(1+multiplyer);

    }
    public void autoattack(Cards attacker, Cards deffender){
        if (repeteattacks==true) {
            new AnimationTimer() {
                long lastUpdate = 0;

                @Override
                public void handle(long now) {
                    if (now - lastUpdate > 1_000_000_000) {
                        lastUpdate = now;
                        if (attacker.gettarget() != null) {
                            Location target = attacker.gettarget();
                            Location deffende = deffender.getloco();
                            if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                                if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                                    battle(attacker, deffender);
                                }
                            }
                        }
                    }
                }
            }.start();

        }
    }
    public boolean aretheytouchingrange(Location loc1, Location loc2, int range) {
        int rowdiff = Math.abs(loc1.getRow() -loc2.getRow());
        int coldiff = Math.abs(loc1.getCol() -loc2.getCol());
        return rowdiff +coldiff<= range;
    }
    public void makepossiblecards(){
        Cards basiccard = new Cards(200, "Melee soldier", 1, "normal", "grey", new Location(4, 4),10,"blue",1,50);
        Cards card5 = new Cards(400, "Heavy Soldier", 1, "normal", "darkgrey", new Location(4, 4),3,"blue",1,70);
        Cards card6 = new Cards(100, "Greatsword Soldier", 1, "normal", "darkgrey", new Location(4, 4),20,"blue",2,70);
        Cards card7 = new Cards(500, "King", 1, "normal", "gold", new Location(4, 4),8,"blue",6,100);
        Cards card13 = new Lightcards(100, "Vampire", 2, "dark", "darkred", new Location(4, 4),10,"blue",1,80);

        Cards card3 = new Cards(250, "Veteran Melee Soldier", 1, "normal", "darkgrey", new Location(4, 4),30,"red",1,80);
        Cards card12 = new Cards(200, "Knight On Horse", 3, "normal", "darkgrey", new Location(4, 4),15,"red",1,75);

        Cards card4 = new Cards(200, "Long Bow Soldier", 1, "normal", "darkgrey", new Location(4, 4),10,"red",10,90);
        Cards card8 = new Cards(200, "Bow soldier", 1, "normal", "grey", new Location(4, 4),8,"red",6,55);
        Cards card9 = new Cards(400, "Heavy Soldier", 1, "normal", "darkgrey", new Location(4, 4),3,"red",1,70);
        Cards card10 = new Cards(100, "Greatsword Soldier", 1, "normal", "darkgrey", new Location(4, 4),20,"red",2,70);
        Cards card14= new Cards(500, "Zombie", 1, "normal", "green", new Location(4, 4),4,"blue",1,100);

        allcardspossible.add(basiccard);
        allcardspossible.add(card3);
        allcardspossible.add(card4);
        allcardspossible.add(card5);
        allcardspossible.add(card6);
        allcardspossible.add(card7);
        allcardspossible.add(card8);
        allcardspossible.add(card9);
        allcardspossible.add(card10);
        allcardspossible.add(card12);
        allcardspossible.add(card13);
        allcardspossible.add(card14);

    }

    public void maketestdeck(){
        hand.clear();
        enemyhand.clear();
        for (int i=0;i<allcardspossible.size();i++){
            enemyhand.add(allcardspossible.get(i));
        }





        System.out.println(enemyhand.get(0).getname());
//        deploycard(hand.get(0));
//        deploycard(hand.get(1));



    }
    public ArrayList<Cards> getallpossiblecards(){
        return allcardspossible;
    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=new ArrayList<>(masterdeck);
        }
    }
    public ArrayList<Cards> getallcardsinplay(){
        return allcardsinplay;
    }
    public void addtodeck(boolean isityourteam, Cards card){
        masterdeck.add(new Cards(card.gethealth(),card.getname(),card.getspeed(),card.getelement(),card.getcolor(),card.getloco(),card.getdamage(),card.getteam(),card.getrange(),card.getcost()));
        resetdeck();

    }
    public void removegold(String team,double amount){
        if (team.equals("blue")){
            p1gold-=amount;
            p1gold=Math.round(p1gold);

        }else if (team.equals("red")){
            p2gold-=amount;
            p2gold=Math.round(p2gold);
        }
    }
    public ArrayList<Cards> gethand(){
        return hand;
    }
    public ArrayList<Cards> getenemyhand(){
        return enemyhand;
    }
    public void drawcard(){
        int rnum=(int)(Math.random()*deck.size());
        Cards card=deck.get(rnum);
        card.setteam("blue");
        hand.add(deck.get(rnum));
        deck.remove(rnum);
        if (deck.size()==0){
            resetdeck();
        }
    }
    public void deploycard(Cards card,int x,int y,int team){
        if (team==1) {
            for (int i = 0; i < hand.size(); i++) {
                if (hand.get(i).getname().equals(card.getname())) {
                    hand.get(i).setdeployspot(x, y);
                    allcardsinplay.add(hand.get(i));
                    hand.get(i).setteam("blue");

                    hand.remove(i);
                    return;

                }
            }
        }else if (team==2){
            for (int i = 0; i <enemyhand.size(); i++) {
                if (enemyhand.get(i).getname().equals(card.getname())) {
                    enemyhand.get(i).setdeployspot(x, y);
                    enemyhand.get(i).setteam("red");

                    allcardsinplay.add(enemyhand.get(i));
                    enemyhand.remove(i);
                    return;

                }
            }
        }

    }

        public void battle(Cards attacker, Cards deffender){
            int rnum=(int)(Math.random()*20);
            double rnum2=Double.valueOf(rnum);
            double refined=rnum2/10;
            double multi= refined+1;
            double finalnum=attacker.getdamage()*multi;
            deffender.damage(finalnum);
            if (attacker.getname().equals("Vampire")){
                attacker.heal(finalnum/2);
                stufftodisplay.add(attacker.getname()+" healed "+finalnum/2+" health from "+deffender.getname());

            }
            if(deffender.areyoudead()==true){
                if (attacker.getname().equals("Zombie")){
                    deffender.zombify(attacker.getteam());

                }else {
                    allcardsinplay.remove(deffender);
                }
            }
            System.out.println(attacker.gethealth());
            System.out.println(deffender.gethealth());
            stufftodisplay.add(attacker.getname()+"of the "+attacker.getteam()+" team" +" attacked "+deffender.getname()+" of the "+deffender.getteam()+" for "+finalnum+" damage");

        }
    public ArrayList<String> getstufftodisplay(){
        ArrayList<String> returnarray = new ArrayList<>(stufftodisplay);
        stufftodisplay.clear();
        return returnarray;
    }


}
