package com.example.tempelate;
import java.util.ArrayList;

public class Supercard extends Cards {

    private int energy = 0;
    private int energyNeeded = 1000;
    private boolean ready = false;
    public Supercard(double health, String name, int speed, String element, String color, Location loco, int damage, String team, int range, double cost) {
        super(health, name, speed, element, color, loco, damage, team, range, cost);
        makesuper();
    }
    public void addenergy(int amount) {
        if (ready==false){
            energy += amount;
            if (energy >= energyNeeded) {
                energy = energyNeeded;
                ready = true;
            }
        }
    }


    public boolean isready() {
        return ready;
    }

    public int getenergy() {
        return energy;
    }

    public int getEnergyneeded() {
        return energyNeeded;
    }

    public void summon() {
        if (ready==true) {
            makesuper();
        }
    }

}