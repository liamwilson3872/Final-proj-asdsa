package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;


public class HelloController {
    private Button btnclick;
    private Label lbldisplay;
    private TextField txtinput;
    @FXML
    private GridPane boardGrid;
    private Button slot1;
    private Button slot2;
    private Game game;
    private Button[][] btn;


    public void initialize() {
        int sizex = 40;
        int sizey = 20;
        btn = new Button[sizex][sizey];
        game=new Game(sizex,sizey);
        for (int x = 0; x < sizex; x++) {
            javafx.scene.layout.ColumnConstraints col = new javafx.scene.layout.ColumnConstraints();
            col.setPercentWidth(100.0 / sizex);
            col.setHgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getColumnConstraints().add(col);
        }
        for (int y = 0; y < sizey; y++) {
            javafx.scene.layout.RowConstraints row = new javafx.scene.layout.RowConstraints();
            row.setPercentHeight(100.0 / sizey);
            row.setVgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getRowConstraints().add(row);
        }

        for (int y = 0; y < sizey; y++) {
            for (int x = 0; x < sizex; x++) {

                Button tile = new Button();
                tile.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                tile.setStyle("-fx-background-color: #444; -fx-border-color: black;");

                boardGrid.add(tile, x, y);
                btn[x][y] = tile;
            }
        }
        game.maketestdeck();
        displayboard();
        buttons();


    }
    public void buttons(){
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Button clicked = (Button) event.getSource();
                if (event.getButton() == MouseButton.PRIMARY) {
                    int row = GridPane.getColumnIndex(clicked);
                    int col = GridPane.getRowIndex(clicked);

                    for (Cards paytonmanningisgreat : game.getallcardsinplay()) {
                        if (paytonmanningisgreat.getloco().comparecords(row, col)) {
                            game.setselectedcard(paytonmanningisgreat);
                            return;
                        }
                    }

                    // If unit already selected → set target
                    if (game.getselectedcard() != null) {
                        game.getselectedcard().settarget(new Location(row, col));
                    }
                }

            }
        };
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);
            }
        }
    }

    public void displayboard(){
        new AnimationTimer() {
            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now-lastUpdate>200_000_000) {
                    lastUpdate = now;
                    game.nexttick();
                    drawtiles();
                    }
                }
        }.start();
    }

    public void drawtiles(){
        for (int i=0;i<game.gettiles().length;i++){
            for (int j=0;j<game.gettiles()[0].length;j++){
//                boardGrid.= new Tile(i,j,"green");
                btn[i][j].setStyle("-fx-background-color: " +game.gettiles()[i][j].getdisplaycolor(game.getallcardsinplay()));
            }
        }    }
    public void btnclick(ActionEvent actionEvent) {
    }
}