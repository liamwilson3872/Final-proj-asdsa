package com.example.tempelate;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> allcardsinplay;
    private Tile[][] tiles;
    private Cards selectedcard;



    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];
        deck=new ArrayList<>();
        masterdeck=new ArrayList<>();
        hand=new ArrayList<>();
        allcardsinplay=new ArrayList<>();
        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"");
            }
        }
        maketestdeck();


    }

    public Cards getselectedcard(){
        return selectedcard;
    }
    public void setselectedcard(Cards card){
        selectedcard=card;
    }
    public void nexttick() {

        for (int i=0;i<allcardsinplay.size();i++) {
            allcardsinplay.get(i).tick();
            if (allcardsinplay.get(i).gettarget() != null) {
                Location target = allcardsinplay.get(i).gettarget();
                Location loco = allcardsinplay.get(i).getloco();
                    for (int j = 0; j < allcardsinplay.size(); j++) {
                        if (i != j) {
                            if (allcardsinplay.get(j).getloco().comparecords(allcardsinplay.get(i).gettarget().getRow(),allcardsinplay.get(i).gettarget().getCol())) {
                                battle(allcardsinplay.get(i), allcardsinplay.get(j));
                            }
                        }
                    }

            }
        }
    }
    public void maketestdeck(){
        for (int i=0;i<1;i++) {
            Cards basiccard = new Cards(200, "guy", 1, "light", "grey", new Location(4, 4),5);
            hand.add(basiccard);
            deploycard(hand.get(0));
        }
    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=masterdeck;
        }
    }
    public ArrayList<Cards> getallcardsinplay(){
        return allcardsinplay;
    }
    public void addtodeck(boolean isityourteam, Cards card){
        masterdeck.add(card);


    }
    public ArrayList<Cards> gethand(){
        return hand;
    }
    public void drawcard(){
        int rnum=(int)(Math.random()*deck.size());
        hand.add(deck.get(rnum));
        deck.remove(rnum);
    }
    public void deploycard(Cards card){
        for (int i=0;i<hand.size();i++){
            if (hand.get(i).getname().equals(card.getname())){
                allcardsinplay.add(card);
                hand.remove(i);


            }
        }

    }

        public void battle(Cards attacker, Cards deffender){
            int rnum=(int)(Math.random()*10);
            double refined=rnum/10;
            double multi= refined+1;
            deffender.damage(attacker.getdamage()*multi);
            if(deffender.areyoudead()==true){
                allcardsinplay.remove(deffender);
            }
            System.out.println(attacker.gethealth());
            System.out.println(deffender.gethealth());

        }


}
