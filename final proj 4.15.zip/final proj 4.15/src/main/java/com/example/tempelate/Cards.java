package com.example.tempelate;

public class Cards {
    protected double health;
    protected String name;
    protected int speed;
    protected double damage;
    protected String element;
    protected String color;
    protected Location loco;
    private Location target;

    public Cards(double health,String name,int speed,String element,String color,Location location,double damage){
        this.health=health;
        this.name=name;
        this.speed=speed;
        this.element=element;
        this.color=color;
        this.damage=damage;
        loco=location;
    }
    public double gethealth(){
        return health;
    }
    public String getname(){
        return name ;
    }
    public int getspeed(){
        return speed;
    }
    public String getelement(){
        return element;
    }
    public String getcolor(){
        return color ;
    }
    public double getdamage(){
        return damage;
    }
    public boolean areyoudead(){
        if (health<=0){
            return true;
        }else{
            return false;
        }
    }
    public Location getloco(){
        return loco;
    }
    public void settarget(Location target) {
        this.target = target;
    }

    public Location gettarget(){
        return target;
    }

    public void damage(double num){
        health-=num;
    }

    public void tick() {
        if (target == null) {
            return;
        }



        if (loco.getRow() < target.getRow()) {
            loco = new Location(loco.getRow() + 1, loco.getCol());
        } else if (loco.getRow() > target.getRow()) {
            loco = new Location(loco.getRow() - 1, loco.getCol());
        } else if (loco.getCol() < target.getCol()) {
            loco = new Location(loco.getRow(), loco.getCol() + 1);
        } else if (loco.getCol() > target.getCol()) {
            loco = new Location(loco.getRow(), loco.getCol() - 1);
        }

    }
}
