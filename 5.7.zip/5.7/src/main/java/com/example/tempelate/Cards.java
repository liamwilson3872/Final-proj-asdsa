package com.example.tempelate;

import java.util.ArrayList;

public class Cards {
    protected double health;
    protected String name;
    protected int speed;
    protected double damage;
    protected String element;
    protected String color;
    protected Location loco;
    private Location target;
    protected String team;
    protected int range;
    protected double cost;
    private double leechval;
    private boolean isitsuper=false;
    private boolean enlightend=false;
    private boolean corrupted=false;
    private boolean assimilated=false;
    private boolean gamblingaddiction=false;
    private boolean turretmode=false;
    public Cards(double health,String name,int speed,String element,String color,Location location,double damage,String team,int range,double cost){
        this.health=health;
        this.name=name;
        this.speed=speed;
        this.element=element;
        this.color=color;
        this.damage=damage;
        loco=location;
        this.team=team;
        this.range=range;
        this.cost=cost;
        leechval=0;
    }
    public double gethealth(){
        return health;
    }
    public String getname(){
        return name ;
    }
    public int getspeed(){
        return speed;
    }
    public String getelement(){
        return element;
    }
    public String getcolor(){
        return color ;
    }
    public double getdamage(){
        return damage;
    }
    public boolean getisitsuper(){
        return isitsuper;
    }
    public void makesuper(){
        isitsuper=true;
    }
    public double getleechval(){
        return leechval;
    }
    public void addleechval(double num){
        leechval+=num;
    }
    public void increasedamage(double num){
        damage+=num;
    }
    public double getcost(){
        return cost;
    }
    public void changespeed(int num){
        speed=num;
    }
    public boolean areyoudead(){
        if (health<=0){
            return true;
        }else{
            return false;
        }
    }
    public boolean getturretmode(){
        return turretmode;
    }
    public void setturretmode(boolean asddsa){
        turretmode=asddsa;
    }
    public void setteam(String team){
        this.team=team;
    }
    public void heal(double num){
        health+=num;
    }
    public double calcelement(String elementattacker,String elementdeffender){
//        if (elementattacker.equals("light"))
        return 98231982198321.0;
    }
    public void zombify(String newteam){
        team=newteam;
        color=newteam;
        health=75;
    }

    public String getteam(){
        return team;
    }
    public void setdeployspot(int x,int y){
        loco=new Location(x,y);
    }
    public Location getloco(){
        return loco;
    }
    public void settarget(Location target) {
        this.target = target;
    }

    public Location gettarget(){
        return target;
    }

    public void damage(double num){
        health-=num;
    }
    public int getrange(){
        return range;
    }

    public ArrayList<Location> makepath(ArrayList<Cards> allcards){
        ArrayList<Location> path=new ArrayList<>();
        Location fakeloco=new Location(loco.getRow(),loco.getCol());
        if (target != null) {
            while (!(fakeloco.comparecords(target.getRow(), target.getCol()))) {
                path.add(fakeloco);
                boolean isitavaliable = true;
                if (fakeloco.getRow() < target.getRow()) {
                    for (int i = 0; i < allcards.size(); i++) {
                        if (allcards.get(i).getloco().comparecords(fakeloco.getRow() + 1, fakeloco.getCol()) == true) {
                            isitavaliable = false;
                        }
                    }
                    if (isitavaliable == true) {
                        fakeloco = new Location(fakeloco.getRow() + 1, fakeloco.getCol());
                    }
                } else if (fakeloco.getRow() > target.getRow()) {
                    for (int i = 0; i < allcards.size(); i++) {
                        if (allcards.get(i).getloco().comparecords(fakeloco.getRow() - 1, fakeloco.getCol()) == true) {
                            isitavaliable = false;
                        }
                    }
                    if (isitavaliable == true) {
                        fakeloco = new Location(fakeloco.getRow() - 1, fakeloco.getCol());
                    }
                } else if (fakeloco.getCol() < target.getCol()) {
                    for (int i = 0; i < allcards.size(); i++) {
                        if (allcards.get(i).getloco().comparecords(fakeloco.getRow(), fakeloco.getCol() + 1) == true) {
                            isitavaliable = false;
                        }
                    }
                    if (isitavaliable == true) {
                        fakeloco = new Location(fakeloco.getRow(), fakeloco.getCol() + 1);
                    }
                } else if (fakeloco.getCol() > target.getCol()) {
                    for (int i = 0; i < allcards.size(); i++) {
                        if (allcards.get(i).getloco().comparecords(fakeloco.getRow(), fakeloco.getCol() - 1) == true) {
                            isitavaliable = false;
                        }
                    }
                    if (isitavaliable == true) {
                        fakeloco = new Location(fakeloco.getRow(), fakeloco.getCol() - 1);
                    }
                }
                if (isitavaliable==false){
                    break;
                }
                path.add(fakeloco);
            }
            return path;
        }
        return path;
    }
    public void enlighten(){
        enlightend=true;
    }
    public boolean isitenlightend(){
        return enlightend;
    }
    public void corrupt(){
        corrupted=true;
    }
    public boolean isitcorrupted(){
        return corrupted;
    }
    public void assimilate(){
        assimilated=true;
    }
    public boolean isitassimilated(){
        return assimilated;
    }
    public void gamblingaddict(){
        gamblingaddiction=true;
    }
    public boolean isitaddicted(){
        return gamblingaddiction;
    }

    public void applyareaeffect(ArrayList<Cards> allCards) {
        int aurarange = 3;
        for (Cards card : allCards) {
            if (card.getteam().equals(this.getteam())) {
                int dist = Math.abs(card.getloco().getRow() - this.getloco().getRow()) + Math.abs(card.getloco().getCol() - this.getloco().getCol());
                if (dist <= aurarange) {
                    if (name.equals("Alexander The Great")) {
                        card.changespeed(card.getspeed() +1);
                        card.enlighten();
                    }

                    if (name.equals("Dracula")) {
                        card.addleechval(5.00);
                        card.corrupt();
                    }

                    if (name.equals("Gambler")) {
                        int rnum=(int)(Math.random()*2);
                        card.gamblingaddict();
                        if (rnum==1){
                            card.heal(20);

                        }else{
                            card.increasedamage(1);
                        }
                    }
                }
            }else{
                int dist = Math.abs(card.getloco().getRow() - this.getloco().getRow()) + Math.abs(card.getloco().getCol() - this.getloco().getCol());
                if (dist <= aurarange) {

                    if (name.equals("The Alien")) {
                        card.assimilate();
                        card.damage(30);
                    }

                }
            }
        }
    }
    public void tick(ArrayList<Cards> allcards) {
        for (int k = 0;k<speed; k++) {
            if (target == null) {
                return;
            }

            boolean isitavaliable = true;
            if (loco.getRow() < target.getRow()) {

                for (int i = 0; i < allcards.size(); i++) {
                    if (allcards.get(i).getloco().comparecords(loco.getRow() + 1, loco.getCol()) == true) {
                        isitavaliable = false;
                    }
                }
                if (isitavaliable == true) {
                    loco = new Location(loco.getRow() + 1, loco.getCol());
                }

            } else if (loco.getRow() > target.getRow()) {
                for (int i = 0; i < allcards.size(); i++) {
                    if (allcards.get(i).getloco().comparecords(loco.getRow() - 1, loco.getCol()) == true) {
                        isitavaliable = false;
                    }
                }
                if (isitavaliable == true) {
                    loco = new Location(loco.getRow() - 1, loco.getCol());
                }
            } else if (loco.getCol() < target.getCol()) {
                for (int i = 0; i < allcards.size(); i++) {
                    if (allcards.get(i).getloco().comparecords(loco.getRow(), loco.getCol() + 1) == true) {
                        isitavaliable = false;
                    }
                }
                if (isitavaliable == true) {
                    loco = new Location(loco.getRow(), loco.getCol() + 1);
                }
            } else if (loco.getCol() > target.getCol()) {
                for (int i = 0; i < allcards.size(); i++) {
                    if (allcards.get(i).getloco().comparecords(loco.getRow(), loco.getCol() - 1) == true) {
                        isitavaliable = false;
                    }
                }
                if (isitavaliable == true) {
                    loco = new Location(loco.getRow(), loco.getCol() - 1);
                }
            }

        }
    }
}
