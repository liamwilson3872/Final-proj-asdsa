package com.example.tempelate;

public class Supercard extends Cards {
    private boolean summoned;
    private int neededtosummon;
    private int energyused;
    public Supercard(double health,String name,int speed,String element,String color,Location loco,int damage,String team,int range,double cost) {
        super(health,name,speed,element,color,loco,damage,team,range,cost);
        summoned=false;
    }
    public void summon(){
        summoned=true;
    }
    public void useenergy(int num){
        energyused+=num;
    }

}
