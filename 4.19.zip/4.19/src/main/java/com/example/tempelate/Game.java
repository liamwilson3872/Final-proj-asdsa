package com.example.tempelate;

import javafx.animation.AnimationTimer;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> allcardsinplay;
    private Tile[][] tiles;
    private Cards selectedcard;
    private boolean repeteattacks;
    private ArrayList<String> stufftodisplay;
    private boolean allowsameteamattacks=false;


    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];
        deck=new ArrayList<>();
        masterdeck=new ArrayList<>();
        hand=new ArrayList<>();
        allcardsinplay=new ArrayList<>();
        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"");
            }
        }
        maketestdeck();
        repeteattacks=false;
        stufftodisplay=new ArrayList<>();
        allowsameteamattacks=true;


    }

    public Cards getselectedcard(){
        return selectedcard;
    }
    public boolean getrepeteattacks(){
        return repeteattacks;
    }
    public void changerepete(boolean news){
        repeteattacks=news;
    }
    public void setselectedcard(Cards card){
        selectedcard=card;
    }
    public void nexttick() {
        for (int i=0;i<allcardsinplay.size();i++) {
            allcardsinplay.get(i).tick(allcardsinplay);

        }
    }



    public void attackselect(Cards attacker, Cards deffender){
        if (repeteattacks==true){
            autoattack(attacker,deffender);
        }else {
            if (attacker.gettarget() != null) {

                Location target = attacker.gettarget();
                Location deffende = deffender.getloco();
                if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                    if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                        if (allowsameteamattacks==true){
                            battle(attacker, deffender);

                        }else {
                            if (!(attacker.getteam().equals(deffender.getteam()))) {
                                battle(attacker, deffender);
                            } else {
                                System.out.println("ERROR CANT ATTACK YOUR OWN TEAM");
                                stufftodisplay.add("cant attack your own team error");
                            }
                        }
                    }
                }
            }
        }



    }
    public void autoattack(Cards attacker, Cards deffender){
        if (repeteattacks==true) {
            new AnimationTimer() {
                long lastUpdate = 0;

                @Override
                public void handle(long now) {
                    if (now - lastUpdate > 1_000_000_000) {
                        lastUpdate = now;
                        if (attacker.gettarget() != null) {

                            Location target = attacker.gettarget();
                            Location deffende = deffender.getloco();
                            if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                                if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                                    battle(attacker, deffender);
                                }
                            }
                        }
                    }
                }
            }.start();

        }
    }
    public boolean aretheytouchingrange(Location loc1, Location loc2, int range) {
        int rowdiff = Math.abs(loc1.getRow() -loc2.getRow());
        int coldiff = Math.abs(loc1.getCol() -loc2.getCol());
        return rowdiff +coldiff<= range;
    }
    public void maketestdeck(){
        Cards basiccard = new Cards(200, "guy", 1, "light", "grey", new Location(4, 4),5,"blue",1);
        Cards card2 = new Cards(200, "ranged guy", 1, "light", "orange", new Location(4, 4),5,"blue",3);
        hand.add(basiccard);
        hand.add(card2);
        hand.add(card2);

//        deploycard(hand.get(0));
//        deploycard(hand.get(1));



    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=masterdeck;
        }
    }
    public ArrayList<Cards> getallcardsinplay(){
        return allcardsinplay;
    }
    public void addtodeck(boolean isityourteam, Cards card){
        masterdeck.add(card);


    }
    public ArrayList<Cards> gethand(){
        return hand;
    }
    public void drawcard(){
        int rnum=(int)(Math.random()*deck.size());
        hand.add(deck.get(rnum));
        deck.remove(rnum);
    }
    public void deploycard(Cards card,int x,int y){
        for (int i=0;i<hand.size();i++){
            if (hand.get(i).getname().equals(card.getname())){
                hand.get(i).setdeployspot(x,y);
                allcardsinplay.add(hand.get(i));
                hand.remove(i);
                return;

            }
        }

    }

        public void battle(Cards attacker, Cards deffender){
            int rnum=(int)(Math.random()*10);
            double refined=rnum/10;
            double multi= refined+1;
            deffender.damage(attacker.getdamage()*multi);
            if(deffender.areyoudead()==true){
                allcardsinplay.remove(deffender);
            }
            System.out.println(attacker.gethealth());
            System.out.println(deffender.gethealth());
            stufftodisplay.add(attacker.getname()+"of the "+attacker.getteam()+" team" +" attacked "+deffender.getname()+" of the "+deffender.getteam()+" for "+multi+" damage");

        }
    public ArrayList<String> getstufftodisplay(){
        ArrayList<String> returnarray = new ArrayList<>(stufftodisplay);
        stufftodisplay.clear();
        return returnarray;
    }


}
