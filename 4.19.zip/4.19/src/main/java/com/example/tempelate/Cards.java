package com.example.tempelate;

import java.util.ArrayList;

public class Cards {
    protected double health;
    protected String name;
    protected int speed;
    protected double damage;
    protected String element;
    protected String color;
    protected Location loco;
    private Location target;
    protected String team;
    protected int range;

    public Cards(double health,String name,int speed,String element,String color,Location location,double damage,String team,int range){
        this.health=health;
        this.name=name;
        this.speed=speed;
        this.element=element;
        this.color=color;
        this.damage=damage;
        loco=location;
        this.team=team;
        this.range=range;
    }
    public double gethealth(){
        return health;
    }
    public String getname(){
        return name ;
    }
    public int getspeed(){
        return speed;
    }
    public String getelement(){
        return element;
    }
    public String getcolor(){
        return color ;
    }
    public double getdamage(){
        return damage;
    }
    public boolean areyoudead(){
        if (health<=0){
            return true;
        }else{
            return false;
        }
    }
    public String getteam(){
        return team;
    }
    public void setdeployspot(int x,int y){
        loco=new Location(x,y);
    }
    public Location getloco(){
        return loco;
    }
    public void settarget(Location target) {
        this.target = target;
    }

    public Location gettarget(){
        return target;
    }

    public void damage(double num){
        health-=num;
    }
    public int getrange(){
        return range;
    }

    public ArrayList<Location> makepath(ArrayList<Cards> allcards){
        ArrayList<Location> path=new ArrayList<>();
        Location fakeloco=new Location(loco.getRow(),loco.getCol());

        while( !(fakeloco.comparecords(target.getRow(),target.getCol()))){
            path.add(fakeloco);
            boolean isitavaliable=true;
            if (fakeloco.getRow() <target.getRow()) {
                for (int i=0;i<allcards.size();i++){
                    if (allcards.get(i).getloco().comparecords(fakeloco.getRow()+1,fakeloco.getCol())==true){
                        isitavaliable=false;
                    }
                }
                if (isitavaliable==true) {
                    fakeloco = new Location(fakeloco.getRow() + 1, fakeloco.getCol());
                }
            } else if (fakeloco.getRow() > target.getRow()) {
                for (int i=0;i<allcards.size();i++){
                    if (allcards.get(i).getloco().comparecords(fakeloco.getRow()-1,fakeloco.getCol())==true){
                        isitavaliable=false;
                    }
                }
                if (isitavaliable==true) {
                    fakeloco = new Location(fakeloco.getRow() - 1, fakeloco.getCol());
                }
            } else if (fakeloco.getCol() < target.getCol()) {
                for (int i=0;i<allcards.size();i++){
                    if (allcards.get(i).getloco().comparecords(fakeloco.getRow(),fakeloco.getCol()+1)==true){
                        isitavaliable=false;
                    }
                }
                if (isitavaliable==true) {
                    fakeloco = new Location(fakeloco.getRow(), fakeloco.getCol() + 1);
                }
            } else if (fakeloco.getCol() > target.getCol()) {
                for (int i=0;i<allcards.size();i++){
                    if (allcards.get(i).getloco().comparecords(fakeloco.getRow(),fakeloco.getCol()-1)==true){
                        isitavaliable=false;
                    }
                }
                if (isitavaliable==true) {
                    fakeloco = new Location(fakeloco.getRow(), fakeloco.getCol() - 1);
                }
            }
            path.add(fakeloco);
        }
        return path;
    }

    public void tick(ArrayList<Cards> allcards) {
        if (target == null) {
            return;
        }

        boolean isitavaliable=true;
        if (loco.getRow() <target.getRow()) {

            for (int i=0;i<allcards.size();i++){
                if (allcards.get(i).getloco().comparecords(loco.getRow()+1,loco.getCol())==true){
                    isitavaliable=false;
                }
            }
            if (isitavaliable==true) {
                loco = new Location(loco.getRow() + 1, loco.getCol());
            }

        } else if (loco.getRow() > target.getRow()) {
            for (int i=0;i<allcards.size();i++){
                if (allcards.get(i).getloco().comparecords(loco.getRow()-1,loco.getCol())==true){
                    isitavaliable=false;
                }
            }
            if (isitavaliable==true) {
                loco = new Location(loco.getRow() - 1, loco.getCol());
            }
        } else if (loco.getCol() < target.getCol()) {
            for (int i=0;i<allcards.size();i++){
                if (allcards.get(i).getloco().comparecords(loco.getRow(),loco.getCol()+1)==true){
                    isitavaliable=false;
                }
            }
            if (isitavaliable==true) {
                loco = new Location(loco.getRow(), loco.getCol() + 1);
            }
        } else if (loco.getCol() > target.getCol()) {
            for (int i=0;i<allcards.size();i++){
                if (allcards.get(i).getloco().comparecords(loco.getRow(),loco.getCol()-1)==true){
                    isitavaliable=false;
                }
            }
            if (isitavaliable==true) {
                loco = new Location(loco.getRow(), loco.getCol() - 1);
            }
        }

    }
}
