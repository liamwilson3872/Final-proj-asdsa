package com.example.tempelate;
import java.util.ArrayList;
public class Lightcards extends Cards{

    public Lightcards(double health,String name,int speed,String element,String color,Location loco,int damage,String team,int range) {
        super(health,name,speed,element,color,loco,damage,team,range);
    }
    public void getattacked(String weather,String element,int damage){
        double damagefinal=damage;
        if (element.equals("light")){
            damagefinal=damage*1.2;
        }
//        if (weather.equals() )
        health-=damagefinal;
    }

}
