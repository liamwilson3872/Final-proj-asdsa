package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;

import java.util.ArrayList;


public class HelloController {
    public ListView p1Hand;
    public ListView p2Hand;
    public TextArea gameLog;
    public Button repeteattacks;
    private Button btnclick;
    private Label lbldisplay;
    private TextField txtinput;
    @FXML
    private GridPane boardGrid;
    @FXML
    private Button slot1;
    @FXML
    private Button slot2;
    private Game game;
    private Button[][] btn;


    public void initialize() {
        int sizex = 40;
        int sizey = 20;
        btn = new Button[sizex][sizey];
        game=new Game(sizex,sizey);
        for (int x = 0; x < sizex; x++) {
            javafx.scene.layout.ColumnConstraints col = new javafx.scene.layout.ColumnConstraints();
            col.setPercentWidth(100.0 / sizex);
            col.setHgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getColumnConstraints().add(col);
        }
        for (int y = 0; y < sizey; y++) {
            javafx.scene.layout.RowConstraints row = new javafx.scene.layout.RowConstraints();
            row.setPercentHeight(100.0 / sizey);
            row.setVgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getRowConstraints().add(row);
        }

        for (int y = 0; y < sizey; y++) {
            for (int x = 0; x < sizex; x++) {

                Button tile = new Button();
                tile.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                tile.setStyle("-fx-background-color: #444; -fx-border-color: black;"  + "; -fx-font-size: 8px;");

                boardGrid.add(tile, x, y);
                btn[x][y] = tile;
            }
        }
        game.maketestdeck();
        displayboard();
        buttons();
        updatelistviews();
        updatelog();


    }
    public void buttons(){
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Button clicked = (Button) event.getSource();
                if (event.getButton() == MouseButton.PRIMARY) {
                    int row = GridPane.getColumnIndex(clicked);
                    int col = GridPane.getRowIndex(clicked);

                    for (Cards unit:game.getallcardsinplay()) {
                        if (unit.getloco().comparecords(row, col)) {
                            game.setselectedcard(unit);
                            return;
                        }
                    }

                    game.setselectedcard(null);
                }else if (event.getButton()==MouseButton.SECONDARY){
                int row = GridPane.getColumnIndex(clicked);
                int col = GridPane.getRowIndex(clicked);
                if (game.getselectedcard() ==null){
                    return;
                }
                for (Cards clickedcard : game.getallcardsinplay()) {
                    if (clickedcard.getloco().comparecords(row, col)) {
                        if (clickedcard != game.getselectedcard()) {
                            game.attackselect(game.getselectedcard(), clickedcard);
                        }

                        return;
                    }
                }
                game.getselectedcard().settarget(new Location(row, col));

                ArrayList<Location> path=new ArrayList<>();
                path=game.getselectedcard().makepath(game.getallcardsinplay());
                for (int i=0;i<path.size();i++){
                    btn[path.get(i).getRow()][path.get(i).getCol()].setText("x");
                }
            }else if (event.getButton()==MouseButton.MIDDLE){
                    int row = GridPane.getColumnIndex(clicked);
                    int col = GridPane.getRowIndex(clicked);
                    game.deploycard(game.gethand().get(playerselection),row,col);
                    updatelistviews();
                }

            }
        };
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);
            }
        }
    }

    public void displayboard(){
        new AnimationTimer() {
            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now-lastUpdate > 800_000_000) {
                    lastUpdate = now;
                    game.nexttick();
                    updatescreens();

                    }
                }
        }.start();
    }

    public void updatescreens(){
        drawtiles();


    }
    public void updatelog(){
        new AnimationTimer() {
            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now - lastUpdate > 200_000_000) {
                    lastUpdate = now;
                    ArrayList<String> logs = game.getstufftodisplay();
                    for (String log : logs) {
                        gameLog.appendText(log + "\n");
                    }
                }
            }
        }.start();
    }

    public void updatelistviews(){
        p1Hand.getItems().clear();
        p2Hand.getItems().clear();

        for (int i=0;i<game.gethand().size();i++){
            p1Hand.getItems().add(game.gethand().get(i).getname());
        }
    }

    public void drawtiles(){
        for (int i = 0; i < game.gettiles().length; i++) {
            for (int j = 0; j < game.gettiles()[0].length; j++) {

                Button tile = btn[i][j];
                tile.setText("");
                String style = "-fx-background-color: " + game.gettiles()[i][j].getdisplaycolor(game.getallcardsinplay()) + ";" + "-fx-font-size: 8;";
                if (game.getselectedcard() != null && game.getselectedcard().getloco().comparecords(i, j)){
                    style+= "-fx-border-color: blue; -fx-border-width: 9;";
                } else {
                    style += "-fx-border-color: black;";
                }
                tile.setStyle(style);
                if (game.getselectedcard() != null) {
                    ArrayList<Location> path = new ArrayList<>();
                    path = game.getselectedcard().makepath(game.getallcardsinplay());
                    for (int d = 0; d < path.size(); d++) {
                        btn[path.get(d).getRow()][path.get(d).getCol()].setText("x");
                    }
                }
            }
        }
        for (Cards card : game.getallcardsinplay()) {
            int row = card.getloco().getRow();
            int col = card.getloco().getCol();
            Button tile = btn[row][col];
            tile.setText(String.valueOf(card.gethealth()));
            String style = "-fx-background-color: " + game.gettiles()[row][col].getdisplaycolor(game.getallcardsinplay()) + ";" + "-fx-font-size: 6;" + "-fx-border-width: 3;";
            if (game.getselectedcard() == card) {
                style += "-fx-border-color: "+game.gettiles()[row][col].getdisplaycolor(game.getallcardsinplay())+ " ;";
            } else {
                style += "-fx-border-color: black;";
            }
            tile.setStyle(style);
        }
    }
    public void btnclick(ActionEvent actionEvent) {
    }

    public void endplayerturn(ActionEvent actionEvent) {
        updatelistviews();
    }
    private int playerselection=0;
    public void selectplayercard(MouseEvent mouseEvent) {
        playerselection=p1Hand.getSelectionModel().getSelectedIndex();
    }
    public void repeteattacksbtn(ActionEvent actionEvent) {
        if (game.getrepeteattacks()==true){
            game.changerepete(false);
            repeteattacks.setStyle("-fx-background-color: red");
        }else{
            game.changerepete(true);
            repeteattacks.setStyle("-fx-background-color: green");

        }
    }
}