package com.example.tempelate;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> allcardsinplay;
    private Tile[][] tiles;
    private Cards selectedcard;



    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];
        deck=new ArrayList<>();
        masterdeck=new ArrayList<>();
        hand=new ArrayList<>();
        allcardsinplay=new ArrayList<>();
        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"");
            }
        }
        maketestdeck();


    }

    public Cards getselectedcard(){
        return selectedcard;
    }
    public void setselectedcard(Cards card){
        selectedcard=card;
    }
    public void nexttick() {

        for (int i=0;i<allcardsinplay.size();i++) {
            allcardsinplay.get(i).tick(allcardsinplay);

        }
    }


    public void attackselect(Cards attacker, Cards deffender){
        if (attacker.gettarget() !=null) {

            for (int j = 0; j < allcardsinplay.size(); j++) {
                Location target = attacker.gettarget();
                Location deffende = deffender.getloco();
                if (target.comparecords(deffende.getRow(),deffende.getCol()) ==false) {
                    if (aretheytouching(target,deffende)) {
                        battle(attacker, deffender);
                    }
                }
            }
        }



    }
    public boolean aretheytouching(Location loc1,Location loc2){
        if (loc1.comparecords(loc2.getRow()+1,loc2.getCol())==true ||loc1.comparecords(loc2.getRow()-1,loc2.getCol())==true ||loc1.comparecords(loc2.getRow(),loc2.getCol()-1)==true || loc1.comparecords(loc2.getRow(),loc2.getCol()+1)==true){
            return true;
        }else{
            return false;
        }
    }
    public void maketestdeck(){
        Cards basiccard = new Cards(200, "guy", 1, "light", "grey", new Location(4, 4),5,"blue");
        Cards card2 = new Cards(200, "afluenza", 1, "light", "orange", new Location(4, 4),5,"blue");
        hand.add(basiccard);
        hand.add(card2);
        hand.add(card2);

//        deploycard(hand.get(0));
//        deploycard(hand.get(1));



    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=masterdeck;
        }
    }
    public ArrayList<Cards> getallcardsinplay(){
        return allcardsinplay;
    }
    public void addtodeck(boolean isityourteam, Cards card){
        masterdeck.add(card);


    }
    public ArrayList<Cards> gethand(){
        return hand;
    }
    public void drawcard(){
        int rnum=(int)(Math.random()*deck.size());
        hand.add(deck.get(rnum));
        deck.remove(rnum);
    }
    public void deploycard(Cards card,int x,int y){
        for (int i=0;i<hand.size();i++){
            if (hand.get(i).getname().equals(card.getname())){
                hand.get(i).setdeployspot(x,y);
                allcardsinplay.add(hand.get(i));
                hand.remove(i);
                return;

            }
        }

    }

        public void battle(Cards attacker, Cards deffender){
            int rnum=(int)(Math.random()*10);
            double refined=rnum/10;
            double multi= refined+1;
            deffender.damage(attacker.getdamage()*multi);
            if(deffender.areyoudead()==true){
                allcardsinplay.remove(deffender);
            }
            System.out.println(attacker.gethealth());
            System.out.println(deffender.gethealth());

        }


}
