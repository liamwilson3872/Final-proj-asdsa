package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;


public class HelloController {
    public ListView p1Hand;
    public ListView p2Hand;
    private Button btnclick;
    private Label lbldisplay;
    private TextField txtinput;
    @FXML
    private GridPane boardGrid;
    @FXML
    private Button slot1;
    @FXML
    private Button slot2;
    private Game game;
    private Button[][] btn;


    public void initialize() {
        int sizex = 40;
        int sizey = 20;
        btn = new Button[sizex][sizey];
        game=new Game(sizex,sizey);
        for (int x = 0; x < sizex; x++) {
            javafx.scene.layout.ColumnConstraints col = new javafx.scene.layout.ColumnConstraints();
            col.setPercentWidth(100.0 / sizex);
            col.setHgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getColumnConstraints().add(col);
        }
        for (int y = 0; y < sizey; y++) {
            javafx.scene.layout.RowConstraints row = new javafx.scene.layout.RowConstraints();
            row.setPercentHeight(100.0 / sizey);
            row.setVgrow(javafx.scene.layout.Priority.ALWAYS);
            boardGrid.getRowConstraints().add(row);
        }

        for (int y = 0; y < sizey; y++) {
            for (int x = 0; x < sizex; x++) {

                Button tile = new Button();
                tile.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                tile.setStyle("-fx-background-color: #444; -fx-border-color: black;"  + "; -fx-font-size: 8px;");

                boardGrid.add(tile, x, y);
                btn[x][y] = tile;
            }
        }
        game.maketestdeck();
        displayboard();
        buttons();
        updatelistviews();


    }
    public void buttons(){
        EventHandler<MouseEvent> z = new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Button clicked = (Button) event.getSource();
                if (event.getButton() == MouseButton.PRIMARY) {
                    int row = GridPane.getColumnIndex(clicked);
                    int col = GridPane.getRowIndex(clicked);
                    for (Cards unit:game.getallcardsinplay()) {
                        if (unit.getloco().comparecords(row, col)) {
                            game.setselectedcard(unit);
                            return;
                        }
                    }
                    btn[row][col].setStyle("-fx-effect: dropshadow(gaussian,"+game.getallcardsinplay().get(barnabis).getteam()+", 20, 0.6, 6, 6);" + "-fx-background-color: "+ game.gettiles()[game.getallcardsinplay().get(barnabis).getloco().getRow()][game.getallcardsinplay().get(barnabis).getloco().getCol()].getdisplaycolor(game.getallcardsinplay()));

                    game.setselectedcard(null);
                }else if (event.getButton()==MouseButton.SECONDARY){
                int row = GridPane.getColumnIndex(clicked);
                int col = GridPane.getRowIndex(clicked);
                if (game.getselectedcard() ==null){
                    return;
                }
                for (Cards clickedcard : game.getallcardsinplay()) {
                    if (clickedcard.getloco().comparecords(row, col)) {
                        if (clickedcard != game.getselectedcard()) {
                            game.attackselect(game.getselectedcard(), clickedcard);
                        }

                        return;
                    }
                }

                // if not clicking a unit → move
                game.getselectedcard().settarget(new Location(row, col));
            }else if (event.getButton()==MouseButton.MIDDLE){
                    int row = GridPane.getColumnIndex(clicked);
                    int col = GridPane.getRowIndex(clicked);
                    game.deploycard(game.gethand().get(playerselection),row,col);
                    updatelistviews();
                }

            }
        };
        for (int i = 0; i < btn.length; i++) {
            for (int j = 0; j < btn[0].length; j++) {
                btn[i][j].setOnMouseClicked(z);
            }
        }
    }

    public void displayboard(){
        new AnimationTimer() {
            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (now-lastUpdate>200_000_000) {
                    lastUpdate = now;
                    game.nexttick();
                    updatescreens();
                    }
                }
        }.start();
    }

    public void updatescreens(){
        drawtiles();
    }

    public void updatelistviews(){
        p1Hand.getItems().clear();
        p2Hand.getItems().clear();

        for (int i=0;i<game.gethand().size();i++){
            p1Hand.getItems().add(game.gethand().get(i).getname());
            System.out.println(game.gethand().get(i).getname());
        }
    }

    public void drawtiles(){
        for (int i=0;i<game.gettiles().length;i++){
            for (int j=0;j<game.gettiles()[0].length;j++){
//                boardGrid.= new Tile(i,j,"green");
                ;
                btn[i][j].setText("");
                btn[i][j].setStyle("-fx-background-color: " + game.gettiles()[i][j].getdisplaycolor(game.getallcardsinplay()));
            }

        }
        for (int barnabis=0;barnabis<game.getallcardsinplay().size();barnabis++){
            btn[game.getallcardsinplay().get(barnabis).getloco().getRow()][game.getallcardsinplay().get(barnabis).getloco().getCol()].setText(String.valueOf(game.getallcardsinplay().get(barnabis).gethealth()));
            System.out.println(game.getallcardsinplay().get(barnabis).gethealth());
            btn[game.getallcardsinplay().get(barnabis).getloco().getRow()][game.getallcardsinplay().get(barnabis).getloco().getCol()].setStyle("-fx-background-color: "+ game.gettiles()[game.getallcardsinplay().get(barnabis).getloco().getRow()][game.getallcardsinplay().get(barnabis).getloco().getCol()].getdisplaycolor(game.getallcardsinplay()));
        }

    }
    public void btnclick(ActionEvent actionEvent) {
    }

    public void endplayerturn(ActionEvent actionEvent) {
        updatelistviews();
    }
    private int playerselection=0;
    public void selectplayercard(MouseEvent mouseEvent) {
        playerselection=p1Hand.getSelectionModel().getSelectedIndex();
    }
}