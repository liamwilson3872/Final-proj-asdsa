package com.example.tempelate;

import javafx.animation.AnimationTimer;

import java.util.ArrayList;

public class Game {
    private ArrayList<Cards> masterdeck;
    private ArrayList<Cards> deck;
    private ArrayList<Cards> hand;
    private ArrayList<Cards> enemymasterdeck;
    private ArrayList<Cards> enemydeck;
    private ArrayList<Cards> enemyhand;
    private ArrayList<Cards> allcardsinplay;
    private Tile[][] tiles;
    private Cards selectedcard;
    private boolean repeteattacks;
    private ArrayList<String> stufftodisplay;
    private boolean allowsameteamattacks=false;
    private double p1gold;
    private double p2gold;
    private int tick;
    private ArrayList<Cards> allcardspossible=new ArrayList<>();
    private int sizex;
    private int sizey;
    private Cards supercard;
    private boolean isaion=false;

    public Game(int sizex,int sizey){
        this.tiles = new Tile[sizex][sizey];
        this.sizex=sizex;
        this.sizey=sizey;
        deck=new ArrayList<>();
        masterdeck=new ArrayList<>();
        hand=new ArrayList<>();
        enemydeck=new ArrayList<>();
        enemymasterdeck=new ArrayList<>();
        enemyhand=new ArrayList<>();
        allcardsinplay=new ArrayList<>();
        for (int i=0;i<sizex;i++){
            for (int j=0;j<sizey;j++){
                tiles[i][j] = new Tile(i,j,"");
            }
        }
        makepossiblecards();
        repeteattacks=false;
        stufftodisplay=new ArrayList<>();
        allowsameteamattacks=false;
        p1gold=9999;
        p2gold=100;
        tick=0;
        maketestdeck();
        ai();

    }
    public void setsupercard(Cards card){

    }

    public Cards getselectedcard(){
        return selectedcard;
    }
    public boolean getrepeteattacks(){
        return repeteattacks;
    }
    public void changerepete(boolean news){
        repeteattacks=news;
    }
    public void setselectedcard(Cards card){
        selectedcard=card;
    }
    public ArrayList<Cards> getdeck(){
        return deck;
    }
    private int delay=0;
    public void nexttick() {
        tick+=1;
        for (int i=0;i<allcardsinplay.size();i++) {
            allcardsinplay.get(i).tick(allcardsinplay);

        }
        if (delay==15){
            calcgold();
            delay=0;
        }else{
            delay+=1;
        }
    }



    public void attackselect(Cards attacker, Cards deffender){
        if (repeteattacks==true){
            autoattack(attacker,deffender);
        }else {
            if (attacker.gettarget() != null) {

                Location target = attacker.gettarget();
                Location deffende = deffender.getloco();
                if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                    if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                        if (allowsameteamattacks==true){
                            battle(attacker, deffender);

                        }else {
                            if (!(attacker.getteam().equals(deffender.getteam()))) {
                                battle(attacker, deffender);
                            } else {
                                System.out.println("ERROR CANT ATTACK YOUR OWN TEAM");
                                stufftodisplay.add("cant attack your own team error");
                            }
                        }
                    }
                }
            }
        }



    }
    public double getplayergold(){
        return p1gold;
    }
    public double getenemygold(){
        return p2gold;
    }
    public void calcgold(){
        double tick=Double.valueOf(this.tick);
        double multiplyer=tick/10;
        p1gold+=(15+multiplyer);
        p2gold+=(15+multiplyer);

    }
    public void autoattack(Cards attacker, Cards deffender){
        if (repeteattacks==true) {
            new AnimationTimer() {
                long lastUpdate = 0;

                @Override
                public void handle(long now) {
                    if (now - lastUpdate > 1_000_000_000) {
                        lastUpdate = now;
                        if (attacker.gettarget() != null) {
                            Location target = attacker.gettarget();
                            Location deffende = deffender.getloco();
                            if (target.comparecords(deffende.getRow(), deffende.getCol()) == false) {
                                if (aretheytouchingrange(target, deffende, attacker.getrange())) {
                                    battle(attacker, deffender);
                                }
                            }
                        }
                    }
                }
            }.start();

        }
    }
    public boolean aretheytouchingrange(Location loc1, Location loc2, int range) {
        int rowdiff = Math.abs(loc1.getRow() -loc2.getRow());
        int coldiff = Math.abs(loc1.getCol() -loc2.getCol());
        return rowdiff +coldiff<= range;
    }
    public boolean isaion(){
        return isaion;
    }
    public void changeai(boolean bol){
        isaion=bol;
    }
    public void sentinalmode(Cards card){
        for (int i=0;i<allcardsinplay.size();i++){
            if (aretheytouchingrange(card.getloco(),allcardsinplay.get(i).getloco(),card.getrange())){
                autoattack(card,allcardsinplay.get(i));
            }
        }
    }
    public void ai() {

        new AnimationTimer() {

            long lastUpdate = 0;

            @Override
            public void handle(long now) {
                if (isaion == true) {
                    if (now - lastUpdate < 1_000_000_000) {
                        return;
                    }
                    System.out.println("na");
                    lastUpdate = now;
                    int reserve = 60;
                    int enemyCount = 0;
                    int playerCount = 0;

                    for (Cards c : allcardsinplay) {
                        if (c.getteam().equals("red")) {
                            enemyCount++;
                        } else {
                            playerCount++;
                        }
                    }
                    if (enemyhand.size() < 2 && p2gold > reserve + 20) {
                        drawenemycard();
                        p2gold -= 20;
                        return;
                    }
                    if (!enemyhand.isEmpty()) {

                        // cheapest cardd
                        Cards bestcard = null;

                        for (Cards cardd : enemyhand) {
                            if (p2gold >= cardd.getcost()) {
                                if (bestcard == null || cardd.getcost() < bestcard.getcost()) {
                                    bestcard = cardd;
                                }
                            }
                        }
                        if (bestcard != null && p2gold > reserve + bestcard.getcost()) {
                            int minX = (sizex * 2) / 3;
                            int x = minX + (int) (Math.random() * (sizex - minX));
                            int y = (int) (Math.random() * sizey);
                            boolean occupied = false;
                            for (Cards c : allcardsinplay) {
                                if (c.getloco().comparecords(x, y)) {
                                    occupied = true;
                                    break;
                                }
                            }
                            if (!occupied) {
                                deploycard(bestcard, x, y, 2);
                                p2gold -= bestcard.getcost();
                                return;
                            }
                        }
                    }
                    for (Cards red : allcardsinplay) {
                        if (red.getteam().equals("red")) {
                            Cards besttarget = null;
                            int bestdist = 999;
                            for (Cards blue : allcardsinplay) {
                                if (blue.getteam().equals("blue")) {
                                    int dist = Math.abs(red.getloco().getRow() - blue.getloco().getRow()) + Math.abs(red.getloco().getCol() - blue.getloco().getCol());
                                    if (dist < bestdist) {
                                        bestdist = dist;
                                        besttarget = blue;
                                    }
                                }
                            }
                            if (besttarget != null) {
                                if (aretheytouchingrange(red.getloco(), besttarget.getloco(), red.getrange())) {
                                    battle(red, besttarget);
                                } else {
                                    red.settarget(besttarget.getloco());
                                }
                            }
                        }
                    }
                    if (playerCount > enemyCount + 2) {
                        for (Cards red : allcardsinplay) {
                            if (red.getteam().equals("red")) {
                                red.changespeed(red.getspeed() + 1);
                            }
                        }
                    }

                }
            }
        }.start();
    }
    public void makepossiblecards(){
        Cards melee = new Cards(200, "Melee soldier", 1, "normal", "grey", new Location(4, 4),10,"blue",1,50);
        Cards heavy = new Cards(400, "Heavy Soldier", 1, "normal", "darkgrey", new Location(4, 4),3,"blue",1,70);
        Cards greatsword = new Cards(100, "Greatsword Soldier", 1, "normal", "darkgrey", new Location(4, 4),20,"blue",2,70);
        Cards king = new Cards(500, "King", 1, "normal", "orange", new Location(4, 4),8,"blue",6,100);
        Cards vamp = new Lightcards(100, "Vampire", 2, "dark", "darkred", new Location(4, 4),10,"blue",1,80);
        Cards vetmelee = new Cards(250, "Veteran Melee Soldier", 1, "normal", "darkgrey", new Location(4, 4),30,"red",1,80);
        Cards knight = new Cards(200, "Knight On Horse", 3, "normal", "brown", new Location(4, 4),15,"red",1,75);
        Cards longbow = new Cards(200, "Long Bow Soldier", 1, "normal", "darkgrey", new Location(4, 4),10,"red",10,90);
        Cards bow = new Cards(200, "Bow soldier", 1, "normal", "grey", new Location(4, 4),8,"red",6,55);
        Cards zombie= new Cards(100, "Zombie", 1, "normal", "green", new Location(4, 4),4,"blue",1,500);
        Cards AlexanderTheGreat= new Supercard(1000, "Alexander The Great", 3, "normal", "gold", new Location(4, 4),4,"blue",1,100);
        Cards Dracula= new Supercard(1000, "Dracula", 2, "normal", "red", new Location(4, 4),5,"blue",1,500);
        Cards Gambler= new Supercard(1000, "Gambler", 1, "normal", "silver", new Location(4, 4),8,"blue",4,500);
        Cards Alien= new Supercard(1000, "The Alien", 4, "normal", "darkgreen", new Location(4, 4),9,"blue",1,500);
        allcardspossible.add(Alien);
        allcardspossible.add(Dracula);
        allcardspossible.add(Gambler);
        allcardspossible.add(AlexanderTheGreat);
        allcardspossible.add(melee);
        allcardspossible.add(heavy);
        allcardspossible.add(greatsword);
        allcardspossible.add(king);
        allcardspossible.add(vetmelee);
        allcardspossible.add(vamp);
        allcardspossible.add(knight);
        allcardspossible.add(longbow);
        allcardspossible.add(bow);
        allcardspossible.add(zombie);


    }

    public void maketestdeck(){
        hand.clear();
        enemymasterdeck.clear();
        enemydeck.clear();
        enemydeck.clear();

        for (int i = 0; i < allcardspossible.size(); i++) {
            enemymasterdeck.add(allcardspossible.get(i));
        }
        enemydeck = new ArrayList<>(enemymasterdeck);
        for (int i = 0; i < 8; i++) {
            drawenemycard();
        }








    }
    public ArrayList<Cards> getallpossiblecards(){
        return allcardspossible;
    }
    public Tile[][] gettiles(){
        return tiles;
    }

    public void resetdeck(){
        if (deck.size()==0){
            deck=new ArrayList<>(masterdeck);
        }
    }
    public void resetenemydeck(){
        if (enemydeck.size()==0){
            enemydeck=new ArrayList<>(enemymasterdeck);
        }
    }
    public ArrayList<Cards> getallcardsinplay(){
        return allcardsinplay;
    }
    public void addtodeck(boolean isityourteam, Cards card){
        masterdeck.add(new Cards(card.gethealth(),card.getname(),card.getspeed(),card.getelement(),card.getcolor(),card.getloco(),card.getdamage(),card.getteam(),card.getrange(),card.getcost()));
        resetdeck();

    }
    public void removegold(String team,double amount){
        if (team.equals("blue")){
            p1gold-=amount;
            p1gold=Math.round(p1gold);

        }else if (team.equals("red")){
            p2gold-=amount;
            p2gold=Math.round(p2gold);
        }
    }
    public ArrayList<Cards> gethand(){
        return hand;
    }
    public ArrayList<Cards> getenemyhand(){
        return enemyhand;
    }
    public void drawcard(){
        int rnum=(int)(Math.random()*deck.size());
        Cards card=deck.get(rnum);
        card.setteam("blue");
        hand.add(deck.get(rnum));
        deck.remove(rnum);
        if (deck.size()==0){
            resetdeck();
        }
    }
    public void drawenemycard(){
        int rnum=(int)(Math.random()*enemydeck.size());
        Cards card=enemydeck.get(rnum);
        card.setteam("red");
        enemyhand.add(enemydeck.get(rnum));
        enemydeck.remove(rnum);
        if (enemydeck.size()==0){
            resetenemydeck();
        }
    }
    public void drawcardcash(){
        if (p1gold>19){
            p1gold-=20;
            drawcard();
        }
    }
    public ArrayList<Cards> getmasterdeck(){
        return masterdeck;
    }
    public void deploycard(Cards card,int x,int y,int team){
        if (team==1) {
            for (int i = 0; i < hand.size(); i++) {
                if (hand.get(i).getname().equals(card.getname())) {
                    hand.get(i).setdeployspot(x, y);
                    if (hand.get(i).getname().equals("Alexander The Great")) {
                        hand.get(i).makesuper();
                    }
                    allcardsinplay.add(hand.get(i));

                    hand.get(i).setteam("blue");


                    hand.remove(i);
                    return;

                }
            }
        } else if (team == 2) {
            int minx = (sizex * 2) / 3;
            if (x<minx) {
                return;
            }
            for (int i = 0; i < enemyhand.size(); i++) {
                if (enemyhand.get(i).getname().equals(card.getname())) {

                    enemyhand.get(i).setdeployspot(x, y);
                    enemyhand.get(i).setteam("red");

                    allcardsinplay.add(enemyhand.get(i));
                    enemyhand.remove(i);
                    return;
                }
            }
        }

    }

        public void battle(Cards attacker, Cards deffender){
            int rnum=(int)(Math.random()*20);
            double rnum2=Double.valueOf(rnum);
            double refined=rnum2/10;
            double multi= refined+1;
            double finalnum=attacker.getdamage()*multi;
            int counterrnum=(int)(Math.random()*20);
            double counterrnum2=Double.valueOf(counterrnum);
            double counterrefined=counterrnum2/10;
            double countermulti= counterrefined+1;
            double counterfinalnum=deffender.getdamage()*countermulti;
            deffender.damage(finalnum);
            attacker.heal(attacker.getleechval());
            if (aretheytouchingrange(deffender.getloco(),attacker.getloco(),deffender.getrange())){
                attacker.damage(counterfinalnum);
            }
            if (attacker.getname().equals("Vampire")){
                attacker.heal(finalnum/2);
                stufftodisplay.add(attacker.getname()+" healed "+finalnum/2+" health from "+deffender.getname());

            }
            if(deffender.areyoudead()==true){
                if (attacker.getname().equals("Zombie")){
                    deffender.zombify(attacker.getteam());

                }else {
                    allcardsinplay.remove(deffender);
                }
            }
            if(attacker.areyoudead()==true){
                if (deffender.getname().equals("Zombie")){
                    attacker.zombify(attacker.getteam());

                }else {
                    allcardsinplay.remove(attacker);
                }
            }

            stufftodisplay.add(attacker.getname()+"of the "+attacker.getteam()+" team" +" attacked "+deffender.getname()+" of the "+deffender.getteam()+" for "+finalnum+" damage");

        }
    public ArrayList<String> getstufftodisplay(){
        ArrayList<String> returnarray = new ArrayList<>(stufftodisplay);
        stufftodisplay.clear();
        return returnarray;
    }


}
